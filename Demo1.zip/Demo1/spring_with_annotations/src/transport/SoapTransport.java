package transport;

import org.springframework.stereotype.Component;

@Component("soap")
public class SoapTransport implements Transport {
	public SoapTransport() {
		System.out.println("in constr of " + getClass().getName());
	}

	@Override
	public void informBank(byte[] data) {
		System.out.println("Communicating info with bank using "
				+ getClass().getName()+" layer");

	}

}
