package transport;

public interface Transport {
	void informBank(byte[] data);

}
