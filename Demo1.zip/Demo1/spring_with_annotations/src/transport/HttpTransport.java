package transport;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("http")
@Scope(value="prototype")
public class HttpTransport implements Transport {
	public HttpTransport() {
		System.out.println("in constr of " + getClass().getName());
	}

	@Override
	public void informBank(byte[] data) {
		System.out.println("Communicating info with bank using "
				+ getClass().getName()+" layer");

	}

}
