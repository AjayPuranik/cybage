package atm;

public interface ATM {
	void deposit(double amt);
	void withdraw(double amt);
	

}
