package atm;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import transport.HttpTransport;
import transport.TestTransport;
import transport.Transport;

@Component("my_atm")
@Scope(value="singleton")
@Lazy(value=true)
public class ATMImpl implements ATM {
	@Autowired
	@Qualifier("testTransport")
	private Transport transport;//=new HttpTransport();
	
	public ATMImpl() {
		System.out.println("in constr of " + getClass().getName()+" "+transport);
	}

	@Override
	public void deposit(double amt) {
		StringBuilder sb=new StringBuilder("Depositing "+amt);
		System.out.println("in deposit");
		transport.informBank(sb.toString().getBytes());

	}

	@Override
	public void withdraw(double amt) {
		System.out.println("in withdraw");
		StringBuilder sb=new StringBuilder("Withdrawing "+amt);
		transport.informBank(sb.toString().getBytes());
	}
	@PostConstruct
	public void myInit()
	{
		System.out.println("in init "+transport);
	}
	@PreDestroy
	public void myDestroy()
	{
		System.out.println("in destroy");
	}
	
}
