package tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import atm.ATM;

public class TestSpring {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"spring-config.xml")) {
			System.out.println("SC started...");
			ATM ref = ctx.getBean("my_atm", ATM.class);
			ref.deposit(100);
			ATM ref2 = ctx.getBean("my_atm", ATM.class);
			ref2.withdraw(100);
			System.out.println(ref==ref2);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
