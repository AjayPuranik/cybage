package com.app.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	public HelloController() {
		System.out.println("in cnstr of " + getClass().getName());
	}

	@RequestMapping("/hello")
	public String sayHello() {
		System.out.println("in say hello");
		return "welcome";
	}

	@RequestMapping("/hello1")
	public ModelAndView sayHello1() {
		System.out.println("in say hello1");
		return new ModelAndView("welcome", "server_dt", new Date());
	}

	@RequestMapping("/hello2")
	public String sayHello2(Model map) {
		System.out.println("in say hello2 " + map);
		map.addAttribute("server_dt", new Date());
		//Arrays -- public static List<T> asList(T... t)
		map.addAttribute("num_list", Arrays.asList(12, 34, 567, 1234));
		System.out.println(map);
		return "welcome";
	}
	@RequestMapping("/hello3")
	public @ResponseBody String sayHello3()
	{
		return "Testing Response body annotation";
	}
	@RequestMapping("/hello4")
	public @ResponseBody List<Integer> sayHello4() {
		System.out.println("in say hello 4");
		//Arrays -- public static List<T> asList(T... t)
		return  Arrays.asList(12, 34, 567, 1234);
	}

}
