package com.cybage.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.project.dao.AttachmentDao;
import com.cybage.project.model.Attachment;
import com.cybage.project.model.DtoToPojoConverter;
import com.cybage.project.model.RequirementDTO;

@Service
@Transactional 
public class AttachmentServiceImpl implements AttachmentService {
	
	@Autowired
	private AttachmentDao attachmentDao;
	
	@Autowired
	private DtoToPojoConverter dtoToPojoConverter;
	
	@Override
	public Integer saveAttachment(RequirementDTO dto,int requirementId) {
		return null;
		//return attachmentDao.saveAttachment(dtoToPojoConverter.toAttachment(dto),requirementId);
	}

	@Override
	public List<Attachment> getAllAttachments() {
		
		return attachmentDao.getAllAttachments();
	}

}
